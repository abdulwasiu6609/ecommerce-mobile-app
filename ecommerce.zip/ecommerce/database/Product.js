// products.js

const products = [
  {
    id: 1,
    title: 'Asaro (Yam Porridge)',
    description:
      'Rare Eat Puff Puff Mix can be made into a deep-fried dough. They are made from yeast dough, shaped into balls and deep-fried until golden brown. It has a doughnut-like texture but slightly ',
    images: ['../assets/images/Image1.png'],
    price: 30,
  },
  {
    id: 2,
    title: 'Moi-moi (bean cake)',
    description:
      'Rare Eat Puff Puff Mix can be made into a deep-fried dough. They are made from yeast dough, shaped into balls and deep-fried until golden brown. It has a doughnut-like texture but slightly ',
    images: ['https://example.com/image2.jpg'],
    price: 30,
  },
  {
    id: 3,
    title: 'Efo riro',
    description:
      'Rare Eat Puff Puff Mix can be made into a deep-fried dough. They are made from yeast dough, shaped into balls and deep-fried until golden brown. It has a doughnut-like texture but slightly ',
    images: ['https://example.com/image3.jpg'],
    price: 30,
  },
  {
    id: 4,
    title: 'African Donut Mix (Puff Puff)',
    description:
      'Rare Eat Puff Puff Mix can be made into a deep-fried dough. They are made from yeast dough, shaped into balls and deep-fried until golden brown. It has a doughnut-like texture but slightly ',
    images: ['https://example.com/image1.jpg'],
    price: 30,
  },
  {
    id: 5,
    title: 'Chicken Stew',
    description:
      'Rare Eat Puff Puff Mix can be made into a deep-fried dough. They are made from yeast dough, shaped into balls and deep-fried until golden brown. It has a doughnut-like texture but slightly ',
    images: ['https://example.com/image2.jpg'],
    price: 30,
  },
  {
    id: 6,
    title: 'Asaro (Yam Porridge)',
    description:
      'Rare Eat Puff Puff Mix can be made into a deep-fried dough. They are made from yeast dough, shaped into balls and deep-fried until golden brown. It has a doughnut-like texture but slightly ',
    images: ['https://example.com/image3.jpg'],
    price: 30,
  },
  // Add more products as needed
];

export default products;
